#include "LlistaIOParInt.hh"

int main(){
    list<ParInt> l;
    LlegirLlistaParInt(l);
    int c1 = 0;
    int c2 = 0;
    int n;
    cin >> n;
    for (list<ParInt>::iterator i = l.begin(); i != l.end(); ++i)
    {
        ParInt aux = (*i);
        if (aux.primer() == n)
        {
            ++c1;
            c2 += aux.segon();
        }
    }
    cout << n <<' ' << c1 << ' ' << c2 << endl;
}

