var searchData=
[
  ['llegir',['llegir',['../class_cjt__estudiants.html#aa24c2d4c36167b2b810ab459435b67a8',1,'Cjt_estudiants::llegir()'],['../class_estudiant.html#af5c4883975828647dfb5ffc6735740e6',1,'Estudiant::llegir()']]]
];
