var searchData=
[
  ['afegir_5festudiant',['afegir_estudiant',['../class_cjt__estudiants.html#a4188715904e017fa15b9ad8bc63112b6',1,'Cjt_estudiants']]],
  ['afegir_5fnota',['afegir_nota',['../class_estudiant.html#a8a2186560dce4ccfc5922d2c98f21305',1,'Estudiant']]]
];
