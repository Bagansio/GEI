#include "mis_funciones.c"
unsigned int char2int(char c);

int mi_atoi(char *s);

int esNumero(char *str);

int Usage(int argc);